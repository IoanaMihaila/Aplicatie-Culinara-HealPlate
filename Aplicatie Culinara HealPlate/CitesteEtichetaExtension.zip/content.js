function extrageIngrediente() {
    const eticheta = document.querySelector(".productIngredients, .product__description");
    if (eticheta) {
        return eticheta.innerText;
    }
    return "Ingrediente nu au fost găsite.";
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.actiune === "extrageIngrediente") {
        const ingrediente = extrageIngrediente();
        sendResponse({ ingrediente });
    }
});
