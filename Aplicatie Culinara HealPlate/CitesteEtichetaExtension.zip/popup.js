document.getElementById("btnTrimite").addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
        chrome.tabs.sendMessage(tab.id, { actiune: "extrageIngrediente" }, async (response) => {
            const ingrediente = response.ingrediente;

            const raspuns = await fetch("https://healplate.ro/api/scanareIngrediente", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ ingrediente })
            });

            const rezultat = await raspuns.json();
            document.getElementById("rezultat").innerText = rezultat.mesaj;
        });
    });
});
